def main():
    print("Hello from yahoo-finance-mcp!")


if __name__ == "__main__":
    main()
